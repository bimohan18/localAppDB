SELECT * FROM DBA_TABLES;
SELECT * FROM ALL_TABLES ORDER BY TABLE_NAME;
SELECT * FROM USER_TABLES ORDER BY TABLE_NAME;

//If it shows CDB$ROOT then it is Container Database, need to set hidden parameter
SHOW CON_NAME;
ALTER SESSION SET "_ORACLE_SCRIPT"=TRUE;
ALTER SESSION SET CURRENT_SCHEMA=sys;
//Once hidden parameter is set, users can be created without C## prefix. Create a Master USER and Grant all access.
CREATE USER MASTERDBA IDENTIFIED BY password;
GRANT CONNECT, RESOURCE TO MASTERDBA;
GRANT CREATE SESSION, CREATE TABLE, CREATE VIEW, CREATE PROCEDURE TO MASTERDBA;
GRANT ALL PRIVILEGES to MASTERDBA;
SELECT 'Hello World!','MM' FROM DUAL;
SELECT * FROM session_privs ORDER BY privilege;

//Either alter session to the Master User or we can create new Connection with Master User Credentials
ALTER SESSION SET CURRENT_SCHEMA=MASTERDBA;


SELECT constraint_name, table_name, column_name
FROM all_cons_columns
WHERE constraint_name = 'SYS_C008408';